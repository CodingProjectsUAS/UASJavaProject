package api;

public class DroneTypes {
	public int id;
	public String manufacturer;
	public String typename;
	public int weight;
	public String max_speed;
	public int battery_capacity;
	public int control_range;
	public int max_carriage;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getTypename() {
		return typename;
	}
	public void setTypename(String typename) {
		this.typename = typename;
	}
	public int getWeight() {
		return weight;
	}
	public void setWeight(int weight) {
		this.weight = weight;
	}
	public String getMax_speed() {
		return max_speed;
	}
	public void setMax_speed(String max_speed) {
		this.max_speed = max_speed;
	}
	public int getBattery_capacity() {
		return battery_capacity;
	}
	public void setBattery_capacity(int battery_capacity) {
		this.battery_capacity = battery_capacity;
	}
	public int getControl_range() {
		return control_range;
	}
	public void setControl_range(int control_range) {
		this.control_range = control_range;
	}
	public int getMax_carriage() {
		return max_carriage;
	}
	public void setMax_carriage(int max_carriage) {
		this.max_carriage = max_carriage;
	}
	
}
