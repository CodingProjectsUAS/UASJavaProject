package menu;
import api.*;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
//import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
//import java.util.List;
import java.util.Set;
//import javax.swing.border.LineBorder;
import org.jxmapviewer.JXMapKit;
import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.painter.Painter;
//import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.viewer.DefaultWaypoint;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.Waypoint;
import org.jxmapviewer.viewer.WaypointPainter;
import javax.swing.GroupLayout.Alignment;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import javax.swing.LayoutStyle.ComponentPlacement;




public class droneMenu extends javax.swing.JFrame {
	private JXMapKit mapKit;
    private Timer timer;
    private SimpleDateFormat st;

    public droneMenu() {
        initComponents();
        initializeMap();
        startTimer();
        }

    private void startTimer() {
        timer = new Timer(1000, e -> updateCurrentTime());
        timer.start();
    }

    private void updateCurrentTime() {
        Date currentTime = new Date();
        st = new SimpleDateFormat("hh.mm.ss a");
        String formattedTime = st.format(currentTime);
        timeShown.setText(formattedTime);
    }
    
    
    private JDialog searchDialog;
    private JTextField searchTextField;

        private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        Menu = new javax.swing.JPanel();
        sideBar = new javax.swing.JPanel();
        time = new javax.swing.JLabel();
        timeShown = new javax.swing.JLabel();
        speed = new javax.swing.JLabel();
        speedShown = new javax.swing.JLabel();
        alignRoll = new javax.swing.JLabel();
        arShown = new javax.swing.JLabel();
        alignPitch = new javax.swing.JLabel();
        apShown = new javax.swing.JLabel();
        alignYaw = new javax.swing.JLabel();
        ayShown = new javax.swing.JLabel();
        longitude = new javax.swing.JLabel();
        ltShown = new javax.swing.JLabel();
        latitude = new javax.swing.JLabel();
        laShown = new javax.swing.JLabel();
        batteryStatus = new javax.swing.JLabel();
        bsShown = new javax.swing.JLabel();
        lastSeen = new javax.swing.JLabel();
        lsShown = new javax.swing.JLabel();
        status = new javax.swing.JLabel();
        statusShown = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        mapPanel = new javax.swing.JPanel();
        map = new javax.swing.JLabel();
        categoriesPanel = new javax.swing.JPanel();
        List2panel = new javax.swing.JScrollPane();
        List2 = new javax.swing.JList<String>();
        jPanel1 = new javax.swing.JPanel();
        backgroundPanel = new javax.swing.JPanel();
        droneMap = new javax.swing.JPanel();
        dMap = new javax.swing.JLabel();
        droneCat = new javax.swing.JPanel();
        dCata = new javax.swing.JLabel();
        backGround = new javax.swing.JLabel();
        connect = new javax.swing.JPanel();
        d_id = new javax.swing.JLabel();
        idShown = new javax.swing.JLabel();
        d_mani = new javax.swing.JLabel();
        maniShown = new javax.swing.JLabel();
        d_type_name = new javax.swing.JLabel();
        type_nameShown = new javax.swing.JLabel();
        d_srn = new javax.swing.JLabel();
        srnShown = new javax.swing.JLabel();
        d_created = new javax.swing.JLabel();
        createdShown = new javax.swing.JLabel();
        d_status = new javax.swing.JLabel();
        statusShown1 = new javax.swing.JLabel();
        d_last_update = new javax.swing.JLabel();
        last_updateShown = new javax.swing.JLabel();
        d_carrweight = new javax.swing.JLabel();
        carrweightShown = new javax.swing.JLabel();
        d_carrtype = new javax.swing.JLabel();
        carrtypeShown = new javax.swing.JLabel();
        d_weight = new javax.swing.JLabel();
        weightShown = new javax.swing.JLabel();
        d_max_speed = new javax.swing.JLabel();
        max_speedShown = new javax.swing.JLabel();
        d_batt_cap = new javax.swing.JLabel();
        batt_capShown = new javax.swing.JLabel();
        d_cont_range = new javax.swing.JLabel();
        cont_rangeShown = new javax.swing.JLabel();
        d_max_carriage = new javax.swing.JLabel();
        max_carriageShown = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        
        
        
        
        
        
        
        
        

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menu.setMinimumSize(new java.awt.Dimension(1000, 625));

        javax.swing.GroupLayout MenuLayout = new javax.swing.GroupLayout(Menu);
        Menu.setLayout(MenuLayout);
        MenuLayout.setHorizontalGroup(
            MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        MenuLayout.setVerticalGroup(
            MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        getContentPane().add(Menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        sideBar.setBackground(java.awt.SystemColor.activeCaption);
        sideBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        time.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        time.setText("Time:");
        sideBar.add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 40, -1));

        timeShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        sideBar.add(timeShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 110, -1));

        speed.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        speed.setText("Speed:");
        sideBar.add(speed, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 50, -1));

        speedShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        speedShown.setText("0");
        sideBar.add(speedShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 100, 90, -1));

        alignRoll.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        alignRoll.setText("align roll:");
        sideBar.add(alignRoll, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 70, -1));

        arShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        arShown.setText("0");
        sideBar.add(arShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, 80, -1));

        alignPitch.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        alignPitch.setText("align pitch:");
        sideBar.add(alignPitch, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 80, -1));

        apShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        apShown.setText("0");
        sideBar.add(apShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 80, -1));

        alignYaw.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        alignYaw.setText("align yaw:");
        sideBar.add(alignYaw, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 70, -1));

        ayShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ayShown.setText("0");
        sideBar.add(ayShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 70, -1));

        longitude.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        longitude.setText("longitude:");
        sideBar.add(longitude, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 70, -1));

        ltShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ltShown.setText("0");
        sideBar.add(ltShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 70, -1));

        latitude.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        latitude.setText("latitude:");
        sideBar.add(latitude, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 60, -1));

        laShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        laShown.setText("0");
        sideBar.add(laShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 60, -1));

        batteryStatus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batteryStatus.setText("battery status:");
        sideBar.add(batteryStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        bsShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bsShown.setText("0");
        sideBar.add(bsShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 60, -1));

        lastSeen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lastSeen.setText("last seen:");
        sideBar.add(lastSeen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 65, -1));

        lsShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lsShown.setText("0");
        sideBar.add(lsShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 60, 20));

        status.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        status.setText("status:");
        sideBar.add(status, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 50, -1));

        statusShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        statusShown.setText("0");
        sideBar.add(statusShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 340, 80, -1));

        jButton1.setBackground(java.awt.SystemColor.activeCaption);
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/refresh_2805355.png"))); // NOI18N
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                
                connect.setBackground(Color.red);
            }
        });
        sideBar.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 30, 30));

        getContentPane().add(sideBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 210, 480));

        mapPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        mapPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        map.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        map.setLayout(new BorderLayout());
        mapPanel.add(map, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 480));
        //map.add(mapKit, BorderLayout.CENTER);

        getContentPane().add(mapPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 110, 730, 480));
        mapPanel.getAccessibleContext().setAccessibleParent(mapPanel);

        categoriesPanel.setBackground(java.awt.Color.white);
        categoriesPanel.setForeground(new java.awt.Color(255, 255, 255));
        categoriesPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        List2panel.setBackground(new java.awt.Color(153, 153, 153));
        List2panel.setBorder(null);
        List2panel.setForeground(new java.awt.Color(255, 255, 255));
        List2panel.setViewportBorder(javax.swing.BorderFactory.createEtchedBorder());
        List2panel.setHorizontalScrollBar(null);

        List2.setBackground(new java.awt.Color(153, 153, 153));
        List2.setBorder(new javax.swing.border.MatteBorder(null));
        List2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        List2.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = {"Altair Aerial AA108","Autel Robotics Evo II","Blade Chroma Camera Drone 2029","Contixo F24 Pro","GoPro Karma 2031","Holy Stone HS100 2024","Hubsan X4 H107D 2028","Snaptain S5C","Holy Stone HS100 2030-68CDB8","Holy Stone HS100 2030-13725D","Holy Stone HS100 2026","Ryze Tello","PowerVision PowerEgg X","Potensic D80","Hubsan X4 H107D 2020","Skydio Skydio 2","Blade Chroma Camera Drone 2027","Blade Chroma Camera Drone 2023","GoPro Karma 2020","GoPro Karma 2027","Yuneec Typhon H Pro","Syma X5C 2022","Syma X5C 2026","Walkera Voyager 4","Contixo F24 Pro"};
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
           
        
        
        List2.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                String selectedValue = List2.getSelectedValue();

                switch(selectedValue) {
                    case "Altair Aerial AA108":
                    	idShown.setText("84");
                    	maniShown.setText("Altair Aerial");
                    	type_nameShown.setText("AA108");
                    	srnShown.setText("AlAA-2025-8FE834");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("0");
                    	carrtypeShown.setText("NOT");
                    	weightShown.setText("85");
                    	max_speedShown.setText("36");
                    	batt_capShown.setText("750");
                    	cont_rangeShown.setText("300");
                    	max_carriageShown.setText("60");
                    	
                        break;
                        
                        
                    case "Blade Chroma Camera Drone 2029":
                    	idShown.setText("85");
                    	maniShown.setText("Blade");
                    	type_nameShown.setText("Chroma Camera Drone");
                    	srnShown.setText("BlCh-2029-29D3FD");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("491");
                    	carrtypeShown.setText("ACT");
                    	weightShown.setText("1630");
                    	max_speedShown.setText("65");
                    	batt_capShown.setText("5400");
                    	cont_rangeShown.setText("2500");
                    	max_carriageShown.setText("600");
                    	
                    	
                        break;
                        
                        
                    case "GoPro Karma 2020":
                    	idShown.setText("85");
                    	maniShown.setText("GoPro");
                    	type_nameShown.setText("Karma");
                    	srnShown.setText("GoKa-2020-28863C");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("7");
                    	carrtypeShown.setText("ACT");
                    	weightShown.setText("1000");
                    	max_speedShown.setText("56");
                    	batt_capShown.setText("5100");
                    	cont_rangeShown.setText("1500");
                    	max_carriageShown.setText("400");
                    	
                    	
                        break;
                        
                        
                    case "Yuneec Typhon H Pro":
                    	idShown.setText("87");
                    	maniShown.setText("Yuneec");
                    	type_nameShown.setText("Typhoon H Pro");
                    	srnShown.setText("YuTy-2028-64A525");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("16");
                    	carrtypeShown.setText("SEN");
                    	weightShown.setText("1995");
                    	max_speedShown.setText("70");
                    	batt_capShown.setText("5400");
                    	cont_rangeShown.setText("2000");
                    	max_carriageShown.setText("100");
                    	
                    	
                        break;
                        
                        
                    case "GoPro Karma 2027":
                    	idShown.setText("88");
                    	maniShown.setText("GoPro");
                    	type_nameShown.setText("Karma");
                    	srnShown.setText("GoKa-2027-351942");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("108");
                    	carrtypeShown.setText("SEN");
                    	weightShown.setText("1000");
                    	max_speedShown.setText("56");
                    	batt_capShown.setText("5100");
                    	cont_rangeShown.setText("1500");
                    	max_carriageShown.setText("400");
                    	
                    	
                        break;
                        
                        
                    case "Syma X5C 2022":
                    	idShown.setText("89");
                    	maniShown.setText("Syma");
                    	type_nameShown.setText("X5C");
                    	srnShown.setText("SyX5-2022-361F57");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("49");
                    	carrtypeShown.setText("SEN");
                    	weightShown.setText("102");
                    	max_speedShown.setText("40");
                    	batt_capShown.setText("500");
                    	cont_rangeShown.setText("150");
                    	max_carriageShown.setText("70");
                    	
                    	
                        break;
                        
                        
                    case "Syma X5C 2026":
                    	idShown.setText("90");
                    	maniShown.setText("Syma");
                    	type_nameShown.setText("X5C");
                    	srnShown.setText("SyX5-2026-85FD53");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("52");
                    	carrtypeShown.setText("ACT");
                    	weightShown.setText("102");
                    	max_speedShown.setText("40");
                    	batt_capShown.setText("500");
                    	cont_rangeShown.setText("150");
                    	max_carriageShown.setText("70");
                    	
                    	
                        break;
                        
                        
                    case "Walkera Voyager 4":
                    	idShown.setText("91");
                    	maniShown.setText("Walkera");
                    	type_nameShown.setText("Voyager 4");
                    	srnShown.setText("WaVo-2026-348807");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("580");
                    	carrtypeShown.setText("ACT");
                    	weightShown.setText("2450");
                    	max_speedShown.setText("80");
                    	batt_capShown.setText("7500");
                    	cont_rangeShown.setText("5000");
                    	max_carriageShown.setText("800");
                    	
                    	
                        break;
                        
                        
                    case "Contixo F24 Pro":
                    	idShown.setText("92");
                    	maniShown.setText("Contixo");
                    	type_nameShown.setText("F24 Pro");
                    	srnShown.setText("CoF2-2027-F774B7");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("228");
                    	carrtypeShown.setText("ACT");
                    	weightShown.setText("520");
                    	max_speedShown.setText("60");
                    	batt_capShown.setText("2500");
                    	cont_rangeShown.setText("1200");
                    	max_carriageShown.setText("250");
                    	
                    	
                        break;
                        
                        
                    case "Holy Stone HS100 2030-68CDB8":
                    	idShown.setText("93");
                    	maniShown.setText("Holy Stone");
                    	type_nameShown.setText("HS100");
                    	srnShown.setText("HoHS-2030-68CDB8");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("267");
                    	carrtypeShown.setText("ACT");
                    	weightShown.setText("700");
                    	max_speedShown.setText("45");
                    	batt_capShown.setText("3500");
                    	cont_rangeShown.setText("500");
                    	max_carriageShown.setText("500");
                    	
                    	
                        break;
                        
                        
                    case "Blade Chroma Camera Drone 2027":
                    	idShown.setText("94");
                    	maniShown.setText("Blade");
                    	type_nameShown.setText("Chroma Camera Drone");
                    	srnShown.setText("BlCh-2027-3B038D");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("191");
                    	carrtypeShown.setText("ACT");
                    	weightShown.setText("1630");
                    	max_speedShown.setText("65");
                    	batt_capShown.setText("5400");
                    	cont_rangeShown.setText("2500");
                    	max_carriageShown.setText("600");
                    	
                    	
                        break;
                        
                        
                    case "Blade Chroma Camera Drone 2023":
                    	idShown.setText("95");
                    	maniShown.setText("Blade");
                    	type_nameShown.setText("Chroma Camera Drone");
                    	srnShown.setText("BlCh-2023-D1E287");
                    	createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	statusShown1.setText("ON");
                    	last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                    	carrweightShown.setText("0");
                    	carrtypeShown.setText("NOT");
                    	weightShown.setText("1630");
                    	max_speedShown.setText("65");
                    	batt_capShown.setText("5400");
                    	cont_rangeShown.setText("2500");
                    	max_carriageShown.setText("600");
                    	
                    	
                        break;
                        
                        
                    case "Holy Stone HS100 2026":
                        idShown.setText("78");
                        maniShown.setText("Altair Aerial");
                        type_nameShown.setText("HS100");
                        srnShown.setText("HoHS-2026-DD1078");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("ON");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("0");
                        carrtypeShown.setText("NOT");
                        weightShown.setText("700");
                        max_speedShown.setText("45");
                        batt_capShown.setText("3500");
                        cont_rangeShown.setText("500");
                        max_carriageShown.setText("500");

                        break;
                        
                        
                        
                    case "GoPro Karma 2031":
                        idShown.setText("79");
                        maniShown.setText("GoPro");
                        type_nameShown.setText("Karma");
                        srnShown.setText("GoKa-2031-AD19BD");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("ON");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("22");
                        carrtypeShown.setText("SEN");
                        weightShown.setText("1000");
                        max_speedShown.setText("56");
                        batt_capShown.setText("5100");
                        cont_rangeShown.setText("1500");
                        max_carriageShown.setText("400");

                        break;
                        
                    case "Potensic D80":
                        idShown.setText("80");
                        maniShown.setText("Potensic");
                        type_nameShown.setText("D80");
                        srnShown.setText("PoD8-2031-B53F1D");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("ON");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("44");
                        carrtypeShown.setText("SEN");
                        weightShown.setText("450");
                        max_speedShown.setText("50");
                        batt_capShown.setText("2800");
                        cont_rangeShown.setText("800");
                        max_carriageShown.setText("200");

                        break;
                        
                    case "Hubsan X4 H107D 2020":
                        idShown.setText("81");
                        maniShown.setText("Hubsan");
                        type_nameShown.setText("X4 H107D");
                        srnShown.setText("HuX4-2020-429586");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("Of");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("47");
                        carrtypeShown.setText("ACT");
                        weightShown.setText("50");
                        max_speedShown.setText("32");
                        batt_capShown.setText("380");
                        cont_rangeShown.setText("200");
                        max_carriageShown.setText("50");

                        break;
                        
                        
                    case "Autel Robotics Evo II":
                        idShown.setText("82");
                        maniShown.setText("Autel Robotics");
                        type_nameShown.setText("Evo II");
                        srnShown.setText("AuEv-2028-D613DA");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("On");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("345");
                        carrtypeShown.setText("ACT");
                        weightShown.setText("1127");
                        max_speedShown.setText("72");
                        batt_capShown.setText("7100");
                        cont_rangeShown.setText("9000");
                        max_carriageShown.setText("800");

                        break;
                        
                        
                        
                    case "Skydio Skydio 2":
                        idShown.setText("83");
                        maniShown.setText("Skydio");
                        type_nameShown.setText("Skydio 2");
                        srnShown.setText("SkSk-2028-2851CF");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("On");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("328");
                        carrtypeShown.setText("SEN");
                        weightShown.setText("775");
                        max_speedShown.setText("58");
                        batt_capShown.setText("4280");
                        cont_rangeShown.setText("3500");
                        max_carriageShown.setText("400");

                        break;
                        
                       
                    case "Holy Stone HS100 2024":
                        idShown.setText("71");
                        maniShown.setText("Holy Stone");
                        type_nameShown.setText("HS100");
                        srnShown.setText("HoHS-2024-F26CA5");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("ON");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("387");
                        carrtypeShown.setText("SEN");
                        weightShown.setText("700");
                        max_speedShown.setText("45");
                        batt_capShown.setText("3500");
                        cont_rangeShown.setText("500");
                        max_carriageShown.setText("500");

                        break;

                    case "Snaptain S5C":
                        idShown.setText("72");
                        maniShown.setText("Snaptain");
                        type_nameShown.setText("S5C");
                        srnShown.setText("ASnS5-2030-360F05");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("OOF");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("73");
                        carrtypeShown.setText("ACT");
                        weightShown.setText("120");
                        max_speedShown.setText("40");
                        batt_capShown.setText("550");
                        cont_rangeShown.setText("150");
                        max_carriageShown.setText("80");

                        break;

                    case "Hubsan X4 H107D 2028":
                        idShown.setText("73");
                        maniShown.setText("Hubsan");
                        type_nameShown.setText("X4 H107D");
                        srnShown.setText("HuX4-2028-208EA8");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("OOF");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("27");
                        carrtypeShown.setText("ACT");
                        weightShown.setText("50");
                        max_speedShown.setText("32");
                        batt_capShown.setText("380");
                        cont_rangeShown.setText("200");
                        max_carriageShown.setText("50");

                        break;

				   case "Holy Stone HS100 2030-13725D":
                        idShown.setText("74");
                        maniShown.setText("Holy Stone");
                        type_nameShown.setText("HS100");
                        srnShown.setText("HoHS-2030-13725D");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("ON");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("499");
                        carrtypeShown.setText("ACT");
                        weightShown.setText("700");
                        max_speedShown.setText("45");
                        batt_capShown.setText("3500");
                        cont_rangeShown.setText("500");
                        max_carriageShown.setText("500");

                        break;

				   case "Ryze Tello":
                        idShown.setText("75");
                        maniShown.setText("Ryze");
                        type_nameShown.setText("Tello");
                        srnShown.setText("RyTe-2027-1F9086");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("ON");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("0");
                        carrtypeShown.setText("NOT");
                        weightShown.setText("80");
                        max_speedShown.setText("28");
                        batt_capShown.setText("1100");
                        cont_rangeShown.setText("100");
                        max_carriageShown.setText("40");

                        break;

				   case "Holy Stone HS100 2022":
                        idShown.setText("76");
                        maniShown.setText("Holy Stone");
                        type_nameShown.setText("HS100");
                        srnShown.setText("HoHS-2022-00A010");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("ON");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("388");
                        carrtypeShown.setText("SEN");
                        weightShown.setText("700");
                        max_speedShown.setText("45");
                        batt_capShown.setText("3500");
                        cont_rangeShown.setText("500");
                        max_carriageShown.setText("500");

                        break;

				   case "PowerVision PowerEgg X":
                        idShown.setText("77");
                        maniShown.setText("PowerVision");
                        type_nameShown.setText("PowerEgg X");
                        srnShown.setText("RyTe-2027-1F9086");
                        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        statusShown1.setText("ON");
                        last_updateShown.setText("Dec. 27, 2023, 9:07 a.m.");
                        carrweightShown.setText("429");
                        carrtypeShown.setText("ACT");
                        weightShown.setText("2100");
                        max_speedShown.setText("64");
                        batt_capShown.setText("5000");
                        cont_rangeShown.setText("3500");
                        max_carriageShown.setText("500");

                        break;
                        
                        
                }}});

        
        List2panel.setViewportView(List2);

        categoriesPanel.add(List2panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 730, 180));

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N

    	d_id.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_id.setText("ID:");

        idShown.setText("71");

        d_mani.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_mani.setText("Manufacturer:");

        maniShown.setText("Holy Stone");

        d_type_name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_type_name.setText("Type name:");

        type_nameShown.setText("\tHS100");

        d_srn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_srn.setText("Serial number:");

        srnShown.setText("HoHS-2024-F26CA5");

        d_created.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_created.setText("Created:");

        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");

        d_status.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_status.setText("\tStatus:");

        statusShown1.setText("ON");

        d_last_update.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_last_update.setText("Last update:");

        last_updateShown.setText("\tDec. 27, 2023, 9:07 a.m.");

        d_carrweight.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_carrweight.setText("\tCarriage Weight:");

        carrweightShown.setText("\t387");

        d_carrtype.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_carrtype.setText("\tCarriage Type:");

        carrtypeShown.setText("\tSEN");

        d_weight.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_weight.setText("Weight:");

        weightShown.setText("\t1000");

        d_max_speed.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_max_speed.setText("Maximum Speed:");

        max_speedShown.setText("\t56");

        d_batt_cap.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_batt_cap.setText("Battery Capacity:");

        batt_capShown.setText("\t5100");

        d_cont_range.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_cont_range.setText("Control Range:");

        cont_rangeShown.setText("\t1500");

        d_max_carriage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_max_carriage.setText("Maximum Carriage:");

        max_carriageShown.setText("\t400");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Drone info");
        jLabel1.setMaximumSize(new java.awt.Dimension(370, 160));
        jLabel1.setPreferredSize(new java.awt.Dimension(93, 25));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(d_id)
                                    .addComponent(d_mani)
                                    .addComponent(d_type_name)
                                    .addComponent(d_srn)
                                    .addComponent(d_created)
                                    .addComponent(d_status)
                                    .addComponent(d_last_update))
                                .addGap(53, 53, 53)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(idShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(maniShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(type_nameShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(srnShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(createdShown, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                                    .addComponent(statusShown1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(last_updateShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cont_rangeShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(d_batt_cap)
                                            .addComponent(d_max_speed)
                                            .addComponent(d_weight)
                                            .addComponent(d_carrtype)
                                            .addComponent(d_carrweight))
                                        .addGap(18, 18, 18)
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(weightShown, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(carrtypeShown, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(carrweightShown, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(max_speedShown, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(batt_capShown, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(d_max_carriage)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(max_carriageShown, javax.swing.GroupLayout.PREFERRED_SIZE, 210, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(d_cont_range)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(296, 296, 296)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(23, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_id)
                    .addComponent(idShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_mani)
                    .addComponent(maniShown)
                    .addComponent(d_carrweight)
                    .addComponent(carrweightShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_type_name)
                    .addComponent(type_nameShown)
                    .addComponent(d_carrtype)
                    .addComponent(carrtypeShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_srn)
                    .addComponent(srnShown)
                    .addComponent(weightShown)
                    .addComponent(d_weight, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_created)
                    .addComponent(createdShown)
                    .addComponent(d_max_speed)
                    .addComponent(max_speedShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_status)
                    .addComponent(statusShown1)
                    .addComponent(d_batt_cap)
                    .addComponent(batt_capShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_last_update)
                    .addComponent(last_updateShown)
                    .addComponent(d_max_carriage)
                    .addComponent(max_carriageShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_cont_range)
                    .addComponent(cont_rangeShown))
                .addGap(140, 140, 140))
        );

        categoriesPanel.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 320));

        getContentPane().add(categoriesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 110, 730, 480));

        backgroundPanel.setMinimumSize(new java.awt.Dimension(1000, 625));
        backgroundPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        droneMap.setBackground(new java.awt.Color(66, 66, 156));
        droneMap.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        droneMap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                droneMapMouseClicked(evt);
            }
        });

        dMap.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        dMap.setForeground(Color.white);
        dMap.setText("Drone Map");
        dMap.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        dMap.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout droneMapLayout = new javax.swing.GroupLayout(droneMap);
        droneMap.setLayout(droneMapLayout);
        droneMapLayout.setHorizontalGroup(
            droneMapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(droneMapLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(dMap)
                .addContainerGap(36, Short.MAX_VALUE))
        );
        droneMapLayout.setVerticalGroup(
            droneMapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(droneMapLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(dMap)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        backgroundPanel.add(droneMap, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 290, 70));
        
        
        connect.setForeground(Color.LIGHT_GRAY);
		connect.setBackground(Color.green);
        //connect.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        

        backgroundPanel.add(connect, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 20, 290, 70));
        
        apilabel = new JLabel("API is connected");
        apilabel.setHorizontalAlignment(SwingConstants.CENTER);
        apilabel.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        apilabel.setForeground(Color.LIGHT_GRAY);
        apilabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        connect.add(apilabel);

        
        droneCat.setBackground(new java.awt.Color(66, 66, 156));
        droneCat.setForeground(Color.WHITE);
        droneCat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        droneCat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                droneCatMouseClicked(evt);
            }
        });

        dCata.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        dCata.setForeground(Color.WHITE);
        dCata.setText("Drone Catalog");
        dCata.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout droneCatLayout = new javax.swing.GroupLayout(droneCat);
        droneCat.setLayout(droneCatLayout);
        droneCatLayout.setHorizontalGroup(
            droneCatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(droneCatLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(dCata)
                .addContainerGap(7, Short.MAX_VALUE))
        );
        droneCatLayout.setVerticalGroup(
            droneCatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(droneCatLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(dCata)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        backgroundPanel.add(droneCat, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, 300, 70));
        backGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/22222222.png"))); // NOI18N
        backGround.setText("jLabel3");
        backgroundPanel.add(backGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 625));

        getContentPane().add(backgroundPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }       
    
    private void droneMapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_droneMapMouseClicked
         mapPanel.setVisible(true);  
         categoriesPanel.setVisible(false);
    }

    private void droneCatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_droneCatMouseClicked
        categoriesPanel.setVisible(true);
        mapPanel.setVisible(false);
    }
    
    private void initializeMap() {
        mapKit = new JXMapKit();
        mapKit.setDefaultProvider(JXMapKit.DefaultProviders.OpenStreetMaps);

        GeoPosition mapPosition = new GeoPosition(50.1350655, 8.6901273);
        mapKit.setAddressLocation(mapPosition);
        int desiredZoomLevel = 50;
        int maxZoomLevel = 60;
        int finalZoomLevel = Math.min(desiredZoomLevel, maxZoomLevel);
        mapKit.setAddressLocation(mapPosition);
        mapKit.setZoom(finalZoomLevel);
        Set<Waypoint> waypoints = new HashSet<>();
        
        Waypoint waypoint = new DefaultWaypoint(new GeoPosition(50.1302907, 8.6938498));
        
        waypoints.add(waypoint);

        Waypoint waypoint2 = new DefaultWaypoint(new GeoPosition(50.1295908, 8.6838498)); 
        waypoints.add(waypoint2);
        
        WaypointPainter<Waypoint> waypointPainter = new WaypointPainter<>();
        waypointPainter.setWaypoints(waypoints);
        mapKit.getMainMap().setOverlayPainter(waypointPainter);
        
        
        
        
        map.setLayout(new BorderLayout());
        map.add(mapKit, BorderLayout.CENTER);
        mapKit.setSize(new Dimension(730, 480));
        map.revalidate();
        map.repaint();
    }
    
    
    int x = 210;
    

    public static void main(String args[]) {
    	System.out.println("API HAS STARTED");
    	String speed = "speed";    	
    	String lastSpeed = api.API.getDroneTypes(speed);
    	System.out.println(lastSpeed);
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException
                | UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(() -> new droneMenu().setVisible(true));
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JList<String> List2;
    private javax.swing.JScrollPane List2panel;
    private javax.swing.JPanel Menu;
    private javax.swing.JLabel alignPitch;
    private javax.swing.JLabel alignRoll;
    private javax.swing.JLabel alignYaw;
    private javax.swing.JLabel apShown;
    private javax.swing.JLabel arShown;
    private javax.swing.JLabel ayShown;
    private javax.swing.JLabel backGround;
    private javax.swing.JPanel backgroundPanel;
    private javax.swing.JLabel batteryStatus;
    private javax.swing.JLabel bsShown;
    private javax.swing.JPanel categoriesPanel;
    private javax.swing.JLabel dCata;
    private javax.swing.JLabel dMap;
    private javax.swing.JPanel droneCat;
    private javax.swing.JPanel droneMap;
    private javax.swing.JButton jButton1;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel laShown;
    private javax.swing.JLabel lastSeen;
    private javax.swing.JLabel latitude;
    private javax.swing.JLabel longitude;
    private javax.swing.JLabel lsShown;
    private javax.swing.JLabel ltShown;
    private javax.swing.JLabel map;
    private javax.swing.JPanel mapPanel;
    private javax.swing.JPanel sideBar;
    private javax.swing.JLabel speed;
    private javax.swing.JLabel speedShown;
    private javax.swing.JLabel status;
    private javax.swing.JLabel statusShown;
    private javax.swing.JLabel time;
    private javax.swing.JLabel timeShown;
    private javax.swing.JPanel connect;
    private javax.swing.JLabel label;
    private javax.swing.JLabel d_id;
    private javax.swing.JLabel idShown;
    private javax.swing.JLabel d_mani;
    private javax.swing.JLabel maniShown;  
    private javax.swing.JLabel d_type_name;
    private javax.swing.JLabel type_nameShown;
    private javax.swing.JLabel d_srn;
    private javax.swing.JLabel srnShown;
    private javax.swing.JLabel d_created;
    private javax.swing.JLabel createdShown;
    private javax.swing.JLabel d_status ;
    private javax.swing.JLabel statusShown1;
    private javax.swing.JLabel d_last_update;
    private javax.swing.JLabel last_updateShown;
    private javax.swing.JLabel d_carrweight;
    private javax.swing.JLabel carrweightShown;
    private javax.swing.JLabel d_carrtype;
    private javax.swing.JLabel carrtypeShown;
    private javax.swing.JLabel d_weight;
    private javax.swing.JLabel weightShown;
    private javax.swing.JLabel d_max_speed;
    private javax.swing.JLabel max_speedShown;
    private javax.swing.JLabel d_batt_cap;
    private javax.swing.JLabel batt_capShown;
    private javax.swing.JLabel d_cont_range;
    private javax.swing.JLabel cont_rangeShown;
    private javax.swing.JLabel d_max_carriage;
    private javax.swing.JLabel max_carriageShown;
    private javax.swing.JLabel jLabel1;
    public javax.swing.JLabel apilabel;
}











