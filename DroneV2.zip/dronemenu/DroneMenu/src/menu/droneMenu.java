package menu;



import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
//import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
//import java.util.List;
import java.util.Set;
//import javax.swing.border.LineBorder;
import org.jxmapviewer.JXMapKit;
//import org.jxmapviewer.JXMapViewer;
import org.jxmapviewer.viewer.DefaultWaypoint;
import org.jxmapviewer.viewer.GeoPosition;
import org.jxmapviewer.viewer.Waypoint;
import org.jxmapviewer.viewer.WaypointPainter;
import api.*;

import menu.DroneTypesList;

import javax.swing.GroupLayout.Alignment;
//import javax.swing.LayoutStyle.ComponentPlacement;




public class droneMenu extends javax.swing.JFrame {
	private JXMapKit mapKit;
    private Timer timer;
    private SimpleDateFormat st;

    public droneMenu() {
        initComponents();
        initializeMap();
        startTimer();
        initializeConnectPanel();
    }

    private void startTimer() {
        timer = new Timer(1000, e -> updateCurrentTime());
        timer.start();
    }

    private void updateCurrentTime() {
        Date currentTime = new Date();
        st = new SimpleDateFormat("hh.mm.ss a");
        String formattedTime = st.format(currentTime);
        timeShown.setText(formattedTime);
    }
    
    private void updateStatus(String text, Color color) {
        SwingUtilities.invokeLater(() -> {
            statusLabel.setText(text);
            statusLabel.setForeground(color);
        });
    }
   

    private void initializeConnectPanel() {
        connect.setBackground(Color.lightGray);
        connect.setLayout(new FlowLayout());

        statusLabel = new JLabel("Not Connected");
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        statusLabel.setForeground(Color.RED);
        connect.add(statusLabel);

        JButton connectButton = new JButton("Connect");
        connectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Simulate API connection logic
                boolean isConnected = simulateApiConnection();

                // Update status indicator based on connection status
                if (isConnected) {
                    updateStatus("Connected", Color.GREEN);
                } else {
                    updateStatus("Not Connected", Color.RED);
                }
            }
        });
        connect.add(connectButton);
    }

    private boolean simulateApiConnection() {
        try {
            // Replace with your actual API endpoint
            String apiUrl = "https://dronesim.facets-labs.com/api/drones/?format=json";
            @SuppressWarnings("deprecation")
			URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set request method (GET, POST, etc.)
            connection.setRequestMethod("GET");

            // Set other request headers or parameters if needed
            // connection.setRequestProperty("HeaderName", "HeaderValue");

            // Get the response code
            int responseCode = connection.getResponseCode();

            // Read the response
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                response.append(line);
            }
            reader.close();

            // Handle the API response as needed
            // For simplicity, just print the response
            System.out.println("API Response: " + response.toString());

            // Return true to indicate a successful connection
            return true;
        } catch (IOException e) {
            // Handle connection error
            e.printStackTrace();
            return false;
        }
    }
    
    
    API api = new API();

 // Get drone types
    String droneTypes = api.getDroneTypes("speed"); 



    
    private JDialog searchDialog;
    private JTextField searchTextField;

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        Menu = new javax.swing.JPanel();
        sideBar = new javax.swing.JPanel();
        time = new javax.swing.JLabel();
        timeShown = new javax.swing.JLabel();
        speed = new javax.swing.JLabel();
        speedShown = new javax.swing.JLabel();
        alignRoll = new javax.swing.JLabel();
        arShown = new javax.swing.JLabel();
        alignPitch = new javax.swing.JLabel();
        apShown = new javax.swing.JLabel();
        alignYaw = new javax.swing.JLabel();
        ayShown = new javax.swing.JLabel();
        longitude = new javax.swing.JLabel();
        ltShown = new javax.swing.JLabel();
        latitude = new javax.swing.JLabel();
        laShown = new javax.swing.JLabel();
        batteryStatus = new javax.swing.JLabel();
        bsShown = new javax.swing.JLabel();
        lastSeen = new javax.swing.JLabel();
        lsShown = new javax.swing.JLabel();
        status = new javax.swing.JLabel();
        statusShown = new javax.swing.JLabel();
        //jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        mapPanel = new javax.swing.JPanel();
        map = new javax.swing.JLabel();
        categoriesPanel = new javax.swing.JPanel();
        List2panel = new javax.swing.JScrollPane();
        List2 = new javax.swing.JList<>();
        jPanel3 = new javax.swing.JPanel();
        dronePic = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        d_id = new javax.swing.JLabel();
        idShown = new javax.swing.JLabel();
        d_mani = new javax.swing.JLabel();
        maniShown = new javax.swing.JLabel();
        d_type_name = new javax.swing.JLabel();
        type_nameShown = new javax.swing.JLabel();
        d_srn = new javax.swing.JLabel();
        srnShown = new javax.swing.JLabel();
        d_created = new javax.swing.JLabel();
        createdShown = new javax.swing.JLabel();
        d_status = new javax.swing.JLabel();
        statusShown1 = new javax.swing.JLabel();
        d_last_update = new javax.swing.JLabel();
        last_updateShown = new javax.swing.JLabel();
        d_carrweight = new javax.swing.JLabel();
        carrweightShown = new javax.swing.JLabel();
        d_carrtype = new javax.swing.JLabel();
        carrtypeShown = new javax.swing.JLabel();
        d_weight = new javax.swing.JLabel();
        weightShown = new javax.swing.JLabel();
        d_max_speed = new javax.swing.JLabel();
        max_speedShown = new javax.swing.JLabel();
        d_batt_cap = new javax.swing.JLabel();
        batt_capShown = new javax.swing.JLabel();
        d_cont_range = new javax.swing.JLabel();
        cont_rangeShown = new javax.swing.JLabel();
        d_max_carriage = new javax.swing.JLabel();
        max_carriageShown = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        backgroundPanel = new javax.swing.JPanel();
        droneMap = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        dMap = new javax.swing.JLabel();
        droneCat = new javax.swing.JPanel();
        dCata = new javax.swing.JLabel();
        backGround = new javax.swing.JLabel();
        connect = new javax.swing.JPanel();

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Menu.setMinimumSize(new java.awt.Dimension(1000, 625));

        javax.swing.GroupLayout MenuLayout = new javax.swing.GroupLayout(Menu);
        Menu.setLayout(MenuLayout);
        MenuLayout.setHorizontalGroup(
            MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        MenuLayout.setVerticalGroup(
            MenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        getContentPane().add(Menu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        sideBar.setBackground(java.awt.SystemColor.activeCaption);
        sideBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        time.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        time.setText("Time:");
        sideBar.add(time, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 40, -1));

        timeShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        timeShown.setText("0");
        sideBar.add(timeShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 110, -1));

        speed.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        speed.setText("Speed:");
        sideBar.add(speed, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 100, 50, -1));

        speedShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        speedShown.setText("0");
        sideBar.add(speedShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 100, 90, -1));

        alignRoll.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        alignRoll.setText("align roll:");
        sideBar.add(alignRoll, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 130, 70, -1));

        arShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        arShown.setText("0");
        sideBar.add(arShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 130, 80, -1));

        alignPitch.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        alignPitch.setText("align pitch:");
        sideBar.add(alignPitch, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 80, -1));

        apShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        apShown.setText("0");
        sideBar.add(apShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 160, 80, -1));

        alignYaw.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        alignYaw.setText("align yaw:");
        sideBar.add(alignYaw, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 70, -1));

        ayShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ayShown.setText("0");
        sideBar.add(ayShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 190, 70, -1));

        longitude.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        longitude.setText("longitude:");
        sideBar.add(longitude, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 220, 70, -1));

        ltShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        ltShown.setText("0");
        sideBar.add(ltShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 220, 70, -1));

        latitude.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        latitude.setText("latitude:");
        sideBar.add(latitude, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 250, 60, -1));

        laShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        laShown.setText("0");
        sideBar.add(laShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 250, 60, -1));

        batteryStatus.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        batteryStatus.setText("battery status:");
        sideBar.add(batteryStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, -1, -1));

        bsShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        bsShown.setText("0");
        sideBar.add(bsShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, 60, -1));

        lastSeen.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lastSeen.setText("last seen:");
        sideBar.add(lastSeen, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 60, -1));

        lsShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        lsShown.setText("0");
        sideBar.add(lsShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 60, 20));

        status.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        status.setText("status:");
        sideBar.add(status, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 340, 50, -1));

        statusShown.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        statusShown.setText("0");
        sideBar.add(statusShown, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 340, 80, -1));

        jButton1.setBackground(java.awt.SystemColor.activeCaption);
        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/refresh_2805355.png"))); // NOI18N
        jButton1.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                //jButton1ActionPerformed(evt);
            }
        });
        sideBar.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 10, 30, 30));

        getContentPane().add(sideBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 210, 480));

        mapPanel.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        mapPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        map.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        map.setLayout(new BorderLayout());
        mapPanel.add(map, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 730, 480));
        //map.add(mapKit, BorderLayout.CENTER);

        getContentPane().add(mapPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 110, 730, 480));
        mapPanel.getAccessibleContext().setAccessibleParent(mapPanel);

        categoriesPanel.setBackground(java.awt.Color.white);
        categoriesPanel.setForeground(new java.awt.Color(255, 255, 255));
        categoriesPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        List2panel.setBackground(new java.awt.Color(153, 153, 153));
        List2panel.setBorder(null);
        List2panel.setForeground(new java.awt.Color(255, 255, 255));
        List2panel.setViewportBorder(javax.swing.BorderFactory.createEtchedBorder());
        List2panel.setHorizontalScrollBar(null);

        List2.setBackground(new java.awt.Color(153, 153, 153));
        List2.setBorder(new javax.swing.border.MatteBorder(null));
        List2.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        List2.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5", "Item 6", "Item 7", "Item 8", "Item 9" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        List2panel.setViewportView(List2);

        categoriesPanel.add(List2panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 370, 730, 110));

        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        dronePic.setBackground(new java.awt.Color(255, 255, 255));
        dronePic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/aerial-drone-isolated-on-white-600nw-1919139251.png"))); // NOI18N
        dronePic.setToolTipText("");
        dronePic.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel3.add(dronePic, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 360, 370));

        categoriesPanel.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 0, 370, 370));

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));
        jPanel1.setFont(new java.awt.Font("Segoe UI", 1, 18));
        
        d_id.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_id.setText("ID:");

        idShown.setText("71");

        d_mani.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_mani.setText("Manufacturer:");

        maniShown.setText("Holy Stone");

        d_type_name.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_type_name.setText("Type name:");

        type_nameShown.setText("\tHS100");

        d_srn.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_srn.setText("Serial number:");

        srnShown.setText("HoHS-2024-F26CA5");

        d_created.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_created.setText("Created:");

        createdShown.setText("Dec. 27, 2023, 9:07 a.m.");

        d_status.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_status.setText("\tStatus:");

        statusShown1.setText("ON");

        d_last_update.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_last_update.setText("Last update:");

        last_updateShown.setText("\tDec. 27, 2023, 9:07 a.m.");

        d_carrweight.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_carrweight.setText("\tCarriage Weight:");

        carrweightShown.setText("\t387");

        d_carrtype.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_carrtype.setText("\tCarriage Type:");

        carrtypeShown.setText("\tSEN");

        d_weight.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_weight.setText("Weight:");

        weightShown.setText("\t1000");

        d_max_speed.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_max_speed.setText("Maximum Speed:");

        max_speedShown.setText("\t56");

        d_batt_cap.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_batt_cap.setText("Battery Capacity:");

        batt_capShown.setText("\t5100");

        d_cont_range.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_cont_range.setText("Control Range:");

        cont_rangeShown.setText("\t1500");

        d_max_carriage.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        d_max_carriage.setText("Maximum Carriage:");

        max_carriageShown.setText("\t400");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setText("Drone info");
        jLabel1.setMaximumSize(new java.awt.Dimension(370, 160));
        jLabel1.setPreferredSize(new java.awt.Dimension(93, 25));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(d_id)
                    .addComponent(d_mani)
                    .addComponent(d_type_name)
                    .addComponent(d_srn)
                    .addComponent(d_created)
                    .addComponent(d_status)
                    .addComponent(d_last_update)
                    .addComponent(d_carrweight)
                    .addComponent(d_carrtype)
                    .addComponent(d_weight)
                    .addComponent(d_max_speed)
                    .addComponent(d_batt_cap)
                    .addComponent(d_cont_range)
                    .addComponent(d_max_carriage))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(idShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(maniShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(type_nameShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(srnShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(createdShown, javax.swing.GroupLayout.DEFAULT_SIZE, 210, Short.MAX_VALUE)
                            .addComponent(statusShown1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(last_updateShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(carrweightShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(carrtypeShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(weightShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(max_speedShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(batt_capShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cont_rangeShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(max_carriageShown, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(19, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_id)
                    .addComponent(idShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_mani)
                    .addComponent(maniShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_type_name)
                    .addComponent(type_nameShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_srn)
                    .addComponent(srnShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_created)
                    .addComponent(createdShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_status)
                    .addComponent(statusShown1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_last_update)
                    .addComponent(last_updateShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_carrweight)
                    .addComponent(carrweightShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_carrtype)
                    .addComponent(carrtypeShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_weight)
                    .addComponent(weightShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_max_speed)
                    .addComponent(max_speedShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_batt_cap)
                    .addComponent(batt_capShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_cont_range)
                    .addComponent(cont_rangeShown))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(d_max_carriage)
                    .addComponent(max_carriageShown))
                .addGap(8, 8, 8))
        );

        categoriesPanel.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, 370));

        getContentPane().add(categoriesPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 110, 730, 480));

        backgroundPanel.setMinimumSize(new java.awt.Dimension(1000, 625));
        backgroundPanel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        droneMap.setBackground(new java.awt.Color(66, 66, 156));
        droneMap.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        droneMap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                droneMapMouseClicked(evt);
            }
        });

        dMap.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        dMap.setForeground(new java.awt.Color(255, 255, 255));
        dMap.setText("Drone Map");
        dMap.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        dMap.setVerifyInputWhenFocusTarget(false);

        javax.swing.GroupLayout droneMapLayout = new javax.swing.GroupLayout(droneMap);
        droneMap.setLayout(droneMapLayout);
        droneMapLayout.setHorizontalGroup(
            droneMapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(droneMapLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(dMap)
                .addContainerGap(36, Short.MAX_VALUE))
        );
        droneMapLayout.setVerticalGroup(
            droneMapLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(droneMapLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(dMap)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        backgroundPanel.add(droneMap, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, 230, 70));
        
        jPanel4.setBackground(new java.awt.Color(66, 66, 156));
        jPanel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        
        //jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        //jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        
        JLabel lblNewLabel = new JLabel("New label");
        lblNewLabel.setForeground(new Color(255, 255, 255));
        lblNewLabel.setFont(new Font("Segoe UI", Font.BOLD, 30));
        
        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4Layout.setHorizontalGroup(
        	jPanel4Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel4Layout.createSequentialGroup()
        			.addGap(26)
        			.addComponent(lblNewLabel)
        			.addContainerGap(63, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
        	jPanel4Layout.createParallelGroup(Alignment.LEADING)
        		.addGroup(jPanel4Layout.createSequentialGroup()
        			.addContainerGap()
        			.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 41, GroupLayout.PREFERRED_SIZE)
        			.addContainerGap(18, Short.MAX_VALUE))
        );
        jPanel4.setLayout(jPanel4Layout);

        backgroundPanel.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(740, 20, 230, 70));
        
        
        connect.setBackground(new java.awt.Color(66, 66, 156));
        connect.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        javax.swing.GroupLayout connectLayout = new javax.swing.GroupLayout(connect);
        connectLayout.setHorizontalGroup(
        	connectLayout.createParallelGroup(Alignment.LEADING)
        		.addGap(0, 262, Short.MAX_VALUE)
        );
        connectLayout.setVerticalGroup(
        	connectLayout.createParallelGroup(Alignment.LEADING)
        		.addGap(0, 80, Short.MAX_VALUE)
        );
        connect.setLayout(connectLayout);

        backgroundPanel.add(connect, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 20, 230, 70));

        
        
        
        
        
        
        
        droneCat.setBackground(new java.awt.Color(66, 66, 156));
        droneCat.setForeground(new java.awt.Color(255, 255, 255));
        droneCat.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        droneCat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                droneCatMouseClicked(evt);
            }
        });

        dCata.setFont(new java.awt.Font("Segoe UI", 1, 30)); // NOI18N
        dCata.setForeground(new java.awt.Color(255, 255, 255));
        dCata.setText("Drone Catalog");
        dCata.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);

        javax.swing.GroupLayout droneCatLayout = new javax.swing.GroupLayout(droneCat);
        droneCat.setLayout(droneCatLayout);
        droneCatLayout.setHorizontalGroup(
            droneCatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(droneCatLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(dCata)
                .addContainerGap(7, Short.MAX_VALUE))
        );
        droneCatLayout.setVerticalGroup(
            droneCatLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(droneCatLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(dCata)
                .addContainerGap(15, Short.MAX_VALUE))
        );

        backgroundPanel.add(droneCat, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 20, 230, 70));
        backGround.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Icons/22222222.png"))); // NOI18N
        backGround.setText("jLabel3");
        backgroundPanel.add(backGround, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1000, 625));

        getContentPane().add(backgroundPanel, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    /*private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
    	List<DroneTypes> droneTypes = API.getDroneTypes();

        // Update the List2 component with the list of drone types
        ListModel<String> model = new DefaultListModel<>();
        for (String droneType : droneTypes) {
            ((DefaultListModel<String>) model).addElement(droneType);
        }
        List2.setModel(model);
        
     // Set the text for each item in the List2 component
        for (int i = 0; i < List2.getModel().getSize(); i++) {
            DroneTypes droneType = List2.getModel().getElementAt(i);
            List2.setListData(new DroneTypes[]{droneType});
            List2.ensureIndexIsVisible(i);
            List2.setSelectedIndex(i);
            JList list = (JList) List2.getSelectedComponent();
            if (list != null) {
                list.setSelectedValue(droneType, true);
                String typename = droneType.getTypename();
                List2.setSelectedValue(typename, i);
            }
        }
    
    }*///GEN-LAST:event_jButton1ActionPerformed
    
    

    private void droneMapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_droneMapMouseClicked
         mapPanel.setVisible(true);  
         categoriesPanel.setVisible(false);
    }//GEN-LAST:event_droneMapMouseClicked

    private void droneCatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_droneCatMouseClicked
        // TODO add your handling code here:
        categoriesPanel.setVisible(true);
        mapPanel.setVisible(false);
    }//GEN-LAST:event_droneCatMouseClicked
    
    private void initializeMap() {
        mapKit = new JXMapKit();
        mapKit.setDefaultProvider(JXMapKit.DefaultProviders.OpenStreetMaps);

        GeoPosition mapPosition = new GeoPosition(50.1350655, 8.6901273);
        mapKit.setAddressLocation(mapPosition);
        int desiredZoomLevel = 50;
        int maxZoomLevel = 60;
        int finalZoomLevel = Math.min(desiredZoomLevel, maxZoomLevel);
        mapKit.setAddressLocation(mapPosition);
        mapKit.setZoom(finalZoomLevel);

        Waypoint waypoint = new DefaultWaypoint(new GeoPosition(50.1302907, 8.6938498));
        Set<Waypoint> waypoints = new HashSet<>();
        waypoints.add(waypoint);

        WaypointPainter<Waypoint> waypointPainter = new WaypointPainter<>();
        waypointPainter.setWaypoints(waypoints);
        mapKit.getMainMap().setOverlayPainter(waypointPainter);

        map.setLayout(new BorderLayout());
        map.add(mapKit, BorderLayout.CENTER);
        mapKit.setSize(new Dimension(730, 480));
        map.revalidate();
        map.repaint();
    }
    
    int x = 210;
    

    public static void main(String args[]) {
    	/*System.out.println("API HAS STARTED");
    	String speed = "speed";    	
    	String lastSpeed = api.API.getDroneTypes(speed);
    	System.out.println(lastSpeed);*/
    	
    	
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException
                | UnsupportedLookAndFeelException ex) {
            ex.printStackTrace();
        }

        java.awt.EventQueue.invokeLater(() -> new droneMenu().setVisible(true));
    }
    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> List2;
    private javax.swing.JScrollPane List2panel;
    private javax.swing.JPanel Menu;
    private javax.swing.JLabel alignPitch;
    private javax.swing.JLabel alignRoll;
    private javax.swing.JLabel alignYaw;
    private javax.swing.JLabel apShown;
    private javax.swing.JLabel arShown;
    private javax.swing.JLabel ayShown;
    private javax.swing.JLabel backGround;
    private javax.swing.JPanel backgroundPanel;
    private javax.swing.JLabel batt_capShown;
    private javax.swing.JLabel batteryStatus;
    private javax.swing.JLabel bsShown;
    private javax.swing.JLabel carrtypeShown;
    private javax.swing.JLabel carrweightShown;
    private javax.swing.JPanel categoriesPanel;
    private javax.swing.JLabel cont_rangeShown;
    private javax.swing.JLabel createdShown;
    private javax.swing.JLabel dCata;
    private javax.swing.JLabel dMap;
    private javax.swing.JLabel d_batt_cap;
    private javax.swing.JLabel d_carrtype;
    private javax.swing.JLabel d_carrweight;
    private javax.swing.JLabel d_cont_range;
    private javax.swing.JLabel d_created;
    private javax.swing.JLabel d_id;
    private javax.swing.JLabel d_last_update;
    private javax.swing.JLabel d_mani;
    private javax.swing.JLabel d_max_carriage;
    private javax.swing.JLabel d_max_speed;
    private javax.swing.JLabel d_srn;
    private javax.swing.JLabel d_status;
    private javax.swing.JLabel d_type_name;
    private javax.swing.JLabel d_weight;
    private javax.swing.JPanel droneCat;
    private javax.swing.JPanel droneMap;
    private javax.swing.JLabel dronePic;
    private javax.swing.JLabel idShown;
    private javax.swing.JButton jButton1;
    private javax.swing.JDialog jDialog1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel laShown;
    private javax.swing.JLabel lastSeen;
    private javax.swing.JLabel last_updateShown;
    private javax.swing.JLabel latitude;
    private javax.swing.JLabel longitude;
    private javax.swing.JLabel lsShown;
    private javax.swing.JLabel ltShown;
    private javax.swing.JLabel maniShown;
    private javax.swing.JLabel map;
    private javax.swing.JPanel mapPanel;
    private javax.swing.JLabel max_carriageShown;
    private javax.swing.JLabel max_speedShown;
    private javax.swing.JPanel sideBar;
    private javax.swing.JLabel speed;
    private javax.swing.JLabel speedShown;
    private javax.swing.JLabel srnShown;
    private javax.swing.JLabel status;
    private javax.swing.JLabel statusShown;
    private javax.swing.JLabel statusShown1;
    private javax.swing.JLabel time;
    private javax.swing.JLabel timeShown;
    private javax.swing.JLabel type_nameShown;
    private javax.swing.JLabel weightShown;
    private javax.swing.JLabel statusLabel;
    private javax.swing.JPanel connect;
    private javax.swing.JPanel jPanel4;
    //private javax.swing.JPanel jLabel2;
}
