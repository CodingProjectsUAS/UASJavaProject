package menu;

import java.util.ArrayList;
import java.util.List;

import api.API;

public class DroneTypesList {
	
	public List<String> droneTypes = new ArrayList<>();

	public void main(String[] args) {
		
		//droneTypes = API.getDroneTypes();
		
		
	}
	    }


